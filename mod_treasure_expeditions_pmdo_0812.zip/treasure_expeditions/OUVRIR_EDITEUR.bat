@echo off
cd /d "%~dp0..\.."
if exist "PMDO.exe" (
  start "" "PMDO.exe" -dev -quest treasure_expeditions
) else if exist "PMDC.exe" (
  start "" "PMDC.exe" -dev -quest treasure_expeditions
) else (
  echo Placer treasure_expeditions dans le dossier MODS de PMDO.
  pause
)

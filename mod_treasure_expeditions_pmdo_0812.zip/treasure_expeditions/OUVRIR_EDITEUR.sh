#!/usr/bin/env bash
set -e
cd -- "$(dirname -- "$0")/../.."
if [[ -x ./PMDO ]]; then exec ./PMDO -dev -quest treasure_expeditions; fi
if [[ -x ./PMDC ]]; then exec ./PMDC -dev -quest treasure_expeditions; fi
echo "Placer treasure_expeditions dans le dossier MODS de PMDO." >&2
exit 1

-- cliff_centre_06_presquile_isthme_etroit_nuit : mod autonome PMDO 0.8.12
local cliff_centre_06_presquile_isthme_etroit_nuit = {}
function cliff_centre_06_presquile_isthme_etroit_nuit.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_06_presquile_isthme_etroit_nuit

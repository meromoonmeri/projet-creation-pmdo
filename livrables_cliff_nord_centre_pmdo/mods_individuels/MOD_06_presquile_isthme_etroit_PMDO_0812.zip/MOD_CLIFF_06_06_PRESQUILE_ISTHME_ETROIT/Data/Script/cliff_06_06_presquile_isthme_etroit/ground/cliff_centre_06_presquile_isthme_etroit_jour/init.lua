-- cliff_centre_06_presquile_isthme_etroit_jour : mod autonome PMDO 0.8.12
local cliff_centre_06_presquile_isthme_etroit_jour = {}
function cliff_centre_06_presquile_isthme_etroit_jour.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_06_presquile_isthme_etroit_jour

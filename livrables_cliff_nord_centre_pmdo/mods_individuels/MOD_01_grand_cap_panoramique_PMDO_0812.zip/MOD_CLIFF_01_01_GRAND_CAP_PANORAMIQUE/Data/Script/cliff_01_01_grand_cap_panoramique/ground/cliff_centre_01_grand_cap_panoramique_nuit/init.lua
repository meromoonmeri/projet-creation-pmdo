-- cliff_centre_01_grand_cap_panoramique_nuit : mod autonome PMDO 0.8.12
local cliff_centre_01_grand_cap_panoramique_nuit = {}
function cliff_centre_01_grand_cap_panoramique_nuit.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_01_grand_cap_panoramique_nuit

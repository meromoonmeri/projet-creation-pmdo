-- cliff_centre_08_cap_asymetrique_est_nuit : mod autonome PMDO 0.8.12
local cliff_centre_08_cap_asymetrique_est_nuit = {}
function cliff_centre_08_cap_asymetrique_est_nuit.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_08_cap_asymetrique_est_nuit

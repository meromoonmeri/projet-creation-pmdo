-- cliff_centre_05_cap_anse_jumelle_jour : mod autonome PMDO 0.8.12
local cliff_centre_05_cap_anse_jumelle_jour = {}
function cliff_centre_05_cap_anse_jumelle_jour.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_05_cap_anse_jumelle_jour

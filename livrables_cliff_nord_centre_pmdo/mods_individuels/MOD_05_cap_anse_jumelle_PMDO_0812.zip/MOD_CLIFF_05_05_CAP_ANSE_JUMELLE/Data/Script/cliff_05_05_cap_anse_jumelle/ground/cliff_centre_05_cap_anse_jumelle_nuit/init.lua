-- cliff_centre_05_cap_anse_jumelle_nuit : mod autonome PMDO 0.8.12
local cliff_centre_05_cap_anse_jumelle_nuit = {}
function cliff_centre_05_cap_anse_jumelle_nuit.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_05_cap_anse_jumelle_nuit

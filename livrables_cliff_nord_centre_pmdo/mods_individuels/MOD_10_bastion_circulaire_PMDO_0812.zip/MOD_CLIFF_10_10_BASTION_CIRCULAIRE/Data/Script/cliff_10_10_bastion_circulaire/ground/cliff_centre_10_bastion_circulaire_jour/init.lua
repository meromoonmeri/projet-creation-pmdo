-- cliff_centre_10_bastion_circulaire_jour : mod autonome PMDO 0.8.12
local cliff_centre_10_bastion_circulaire_jour = {}
function cliff_centre_10_bastion_circulaire_jour.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_10_bastion_circulaire_jour

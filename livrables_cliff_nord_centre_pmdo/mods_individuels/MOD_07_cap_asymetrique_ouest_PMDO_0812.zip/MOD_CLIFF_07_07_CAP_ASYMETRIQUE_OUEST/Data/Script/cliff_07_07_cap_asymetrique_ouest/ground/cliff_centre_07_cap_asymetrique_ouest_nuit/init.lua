-- cliff_centre_07_cap_asymetrique_ouest_nuit : mod autonome PMDO 0.8.12
local cliff_centre_07_cap_asymetrique_ouest_nuit = {}
function cliff_centre_07_cap_asymetrique_ouest_nuit.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_07_cap_asymetrique_ouest_nuit

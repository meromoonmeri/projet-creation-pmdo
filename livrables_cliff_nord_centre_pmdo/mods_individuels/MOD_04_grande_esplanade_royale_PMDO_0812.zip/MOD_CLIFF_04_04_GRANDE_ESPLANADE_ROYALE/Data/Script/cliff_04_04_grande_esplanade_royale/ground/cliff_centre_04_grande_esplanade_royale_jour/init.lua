-- cliff_centre_04_grande_esplanade_royale_jour : mod autonome PMDO 0.8.12
local cliff_centre_04_grande_esplanade_royale_jour = {}
function cliff_centre_04_grande_esplanade_royale_jour.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_04_grande_esplanade_royale_jour

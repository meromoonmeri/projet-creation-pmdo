-- cliff_centre_04_grande_esplanade_royale_nuit : mod autonome PMDO 0.8.12
local cliff_centre_04_grande_esplanade_royale_nuit = {}
function cliff_centre_04_grande_esplanade_royale_nuit.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_04_grande_esplanade_royale_nuit

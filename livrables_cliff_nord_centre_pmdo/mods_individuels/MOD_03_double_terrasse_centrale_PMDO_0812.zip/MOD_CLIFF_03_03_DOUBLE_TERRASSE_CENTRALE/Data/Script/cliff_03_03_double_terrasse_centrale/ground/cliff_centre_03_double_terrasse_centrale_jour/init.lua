-- cliff_centre_03_double_terrasse_centrale_jour : mod autonome PMDO 0.8.12
local cliff_centre_03_double_terrasse_centrale_jour = {}
function cliff_centre_03_double_terrasse_centrale_jour.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_03_double_terrasse_centrale_jour

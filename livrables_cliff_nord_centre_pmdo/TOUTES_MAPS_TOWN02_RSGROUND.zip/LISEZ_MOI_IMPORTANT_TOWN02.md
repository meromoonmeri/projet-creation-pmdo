# PACK UNIVERSEL `TOUTES_MAPS_TOWN02_RSGROUND.zip` — 78 CARTES `.rsground` 100 % COMPATIBLES `meromoonmeri/town02`

## Zéro fichier `.tile` à copier · Zéro fichier `.dir` à copier · Zéro crash de désérialisation !

Les **78 fichiers `.rsground`** contenus dans `Data/Ground/` utilisent **exclusivement** les banques de tuiles `Content/Tile/*.tile` déjà présentes dans `meromoonmeri/town02` :
1. **40 cartes `cliff_centre_<01..10>_<nuit|aube|crepuscule|jour>.rsground`** : les **10 falaises côtières au premier plan** (`Grass Métano` sans roche) dans les **4 ambiances animées de La Scène du Réveil** (`Nuit Pleine Lune + étoiles + reflet lunaire 12 phases`, `Aube`, `Crépuscule`, `Jour V24P04A`) avec les **nuages Chunsoft à 3 plans de l'ancienne version**.
2. **13 cartes `guilde_vide_*.rsground` & `cliff_north.rsground`** : tout le réseau de salles de Guilde vides en bois Métano + `cliff_north`.
3. **5 cartes `metano_gen_{accueil,cafe,casino,salon_bas,salon_haut}.rsground`** : les 5 salles intérieures du réseau Métano.
4. **4 cartes `cliffdaytest.rsground`, `cliffdaytest_nuit.rsground`, `cliffnordouesttest1.rsground`, `cliffnordouesttest1_nuit.rsground`** : réparées à 100 % sur `town02`.
5. **16 planches-palettes `palette_*_{jour,nuit}.rsground`** : tous les bâtiments & meubles du projet (`Treehouses Guilde`, `Arbres Jardin Secret & Sky Peak`, `Arbres Sans Escalier`, `Spinda Café Dojo`, `Maisons Forgelina Kangourex`, `Tentes & Huttes Forgelina`, `Tentes Évoli Bourg-Trésor`, `Comptoirs & Scène Spinda/Kirlia/Cabaret`) prêts à copier-coller directement entre cartes dans le Ground Editor !

---

## ⚠️ RÈGLE CRITIQUE PMDO 0.8.12 POUR ÉVITER `NullReferenceException` À L'ÉCRAN-TITRE !

Dans le code source officiel de **RogueEssence 0.8.12** (`GroundEditViewModel.cs`, lignes `306` et `314`), `mnuOpen_Click -> DoLoad(mapName)` lit **`ZoneManager.Instance.CurrentZone`**.
Or **sur l'écran-titre** (juste après `ExampleSvc: Deinit..` / `LuaEngine.OnGraphicsUnload()..`), **`CurrentZone` vaut `null`** — ce qui provoque `System.NullReferenceException` **sur absolument n'importe quel `.rsground`** si aucune partie / zone n'est active !

### Procédure en 2 clics (100 % garantie sans crash) :
1. Copiez les fichiers `.rsground` souhaités (ou tout le dossier `Data/Ground/` de cette archive) dans :
   `town02/Data/Ground/`
2. Lancez `RogueEssence.exe -dev`, puis **AVANT de cliquer sur `Edit -> Edit Ground`** :
   - **Soit** chargez votre sauvegarde sur le jeu principal ;
   - **Soit** dans la fenêtre **Dev** -> onglet **`Player`** ou **`Dev`** -> choisissez n'importe quelle Zone existante (ex. **`master_zone`** ou **`metano_town`**) -> cliquez sur **`Travel`**.
3. Cliquez maintenant sur **`Edit` -> `Edit Ground` -> `File` -> `Open`** et ouvrez **n'importe laquelle des 78 cartes `.rsground`** !

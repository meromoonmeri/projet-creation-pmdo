-- cliff_centre_09_trois_paliers_sacres_jour : animations Scène du Réveil V2 100 % natives moteur PMDO 0.8.12
local cliff_centre_09_trois_paliers_sacres_jour = {}
function cliff_centre_09_trois_paliers_sacres_jour.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_09_trois_paliers_sacres_jour

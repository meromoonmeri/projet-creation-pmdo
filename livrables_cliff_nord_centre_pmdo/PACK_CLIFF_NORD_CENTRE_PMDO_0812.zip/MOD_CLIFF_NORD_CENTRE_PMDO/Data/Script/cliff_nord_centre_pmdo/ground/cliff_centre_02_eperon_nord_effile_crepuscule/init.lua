-- cliff_centre_02_eperon_nord_effile_crepuscule : animations Scène du Réveil V2 100 % natives moteur PMDO 0.8.12
local cliff_centre_02_eperon_nord_effile_crepuscule = {}
function cliff_centre_02_eperon_nord_effile_crepuscule.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_02_eperon_nord_effile_crepuscule

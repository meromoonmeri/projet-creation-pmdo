-- cliff_centre_03_double_terrasse_centrale_jour : animations ciel/mer 100 % natives PMDO 0.8.12
local cliff_centre_03_double_terrasse_centrale_jour = {}
function cliff_centre_03_double_terrasse_centrale_jour.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_03_double_terrasse_centrale_jour

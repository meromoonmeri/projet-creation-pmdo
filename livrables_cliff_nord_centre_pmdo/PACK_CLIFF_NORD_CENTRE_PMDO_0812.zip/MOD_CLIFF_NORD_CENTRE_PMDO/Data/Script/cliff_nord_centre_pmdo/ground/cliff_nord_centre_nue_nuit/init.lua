-- cliff_nord_centre_nue_nuit : animations ciel/mer/cascade 100 % natives moteur PMDO 0.8.12
local cliff_nord_centre_nue_nuit = {}
function cliff_nord_centre_nue_nuit.Init(map)
  COMMON.RespawnAllies()
end
return cliff_nord_centre_nue_nuit

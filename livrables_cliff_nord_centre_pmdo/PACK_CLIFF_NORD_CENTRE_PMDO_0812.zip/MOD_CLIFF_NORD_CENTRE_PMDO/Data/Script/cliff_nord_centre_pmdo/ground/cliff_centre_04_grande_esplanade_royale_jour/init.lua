-- cliff_centre_04_grande_esplanade_royale_jour : animations ciel/mer 100 % natives PMDO 0.8.12
local cliff_centre_04_grande_esplanade_royale_jour = {}
function cliff_centre_04_grande_esplanade_royale_jour.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_04_grande_esplanade_royale_jour

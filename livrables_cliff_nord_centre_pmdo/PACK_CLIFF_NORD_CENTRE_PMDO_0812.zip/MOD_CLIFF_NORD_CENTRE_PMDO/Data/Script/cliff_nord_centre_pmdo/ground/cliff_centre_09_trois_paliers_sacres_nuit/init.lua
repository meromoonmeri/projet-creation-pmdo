-- cliff_centre_09_trois_paliers_sacres_nuit : falaise au premier plan 100 % canonique Métano + animations PMDO 0.8.12
local cliff_centre_09_trois_paliers_sacres_nuit = {}
function cliff_centre_09_trois_paliers_sacres_nuit.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_09_trois_paliers_sacres_nuit

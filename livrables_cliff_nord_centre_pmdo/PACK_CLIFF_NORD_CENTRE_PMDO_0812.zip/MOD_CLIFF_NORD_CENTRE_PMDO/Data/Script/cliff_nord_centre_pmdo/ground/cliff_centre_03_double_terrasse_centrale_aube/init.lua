-- cliff_centre_03_double_terrasse_centrale_aube : animations Scène du Réveil V2 100 % natives moteur PMDO 0.8.12
local cliff_centre_03_double_terrasse_centrale_aube = {}
function cliff_centre_03_double_terrasse_centrale_aube.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_03_double_terrasse_centrale_aube

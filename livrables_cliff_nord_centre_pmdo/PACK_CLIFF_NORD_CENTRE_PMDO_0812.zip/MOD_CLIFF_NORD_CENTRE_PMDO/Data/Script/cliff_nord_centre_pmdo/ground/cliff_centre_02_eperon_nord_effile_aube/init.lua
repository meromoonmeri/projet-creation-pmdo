-- cliff_centre_02_eperon_nord_effile_aube : animations Scène du Réveil V2 100 % natives moteur PMDO 0.8.12
local cliff_centre_02_eperon_nord_effile_aube = {}
function cliff_centre_02_eperon_nord_effile_aube.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_02_eperon_nord_effile_aube

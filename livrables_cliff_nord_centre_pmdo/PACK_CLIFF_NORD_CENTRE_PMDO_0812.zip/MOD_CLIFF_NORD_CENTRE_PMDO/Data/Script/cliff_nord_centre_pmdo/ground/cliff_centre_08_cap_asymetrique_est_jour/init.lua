-- cliff_centre_08_cap_asymetrique_est_jour : animations ciel/mer 100 % natives PMDO 0.8.12
local cliff_centre_08_cap_asymetrique_est_jour = {}
function cliff_centre_08_cap_asymetrique_est_jour.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_08_cap_asymetrique_est_jour

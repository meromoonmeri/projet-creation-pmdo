-- cliff_centre_01_grand_cap_panoramique_nuit : animations ciel/mer 100 % natives PMDO 0.8.12
local cliff_centre_01_grand_cap_panoramique_nuit = {}
function cliff_centre_01_grand_cap_panoramique_nuit.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_01_grand_cap_panoramique_nuit

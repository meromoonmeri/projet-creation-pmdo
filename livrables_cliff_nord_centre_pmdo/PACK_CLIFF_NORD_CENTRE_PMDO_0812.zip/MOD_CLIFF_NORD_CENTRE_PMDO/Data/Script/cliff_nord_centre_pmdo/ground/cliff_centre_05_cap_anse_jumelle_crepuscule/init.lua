-- cliff_centre_05_cap_anse_jumelle_crepuscule : animations Scène du Réveil V2 100 % natives moteur PMDO 0.8.12
local cliff_centre_05_cap_anse_jumelle_crepuscule = {}
function cliff_centre_05_cap_anse_jumelle_crepuscule.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_05_cap_anse_jumelle_crepuscule

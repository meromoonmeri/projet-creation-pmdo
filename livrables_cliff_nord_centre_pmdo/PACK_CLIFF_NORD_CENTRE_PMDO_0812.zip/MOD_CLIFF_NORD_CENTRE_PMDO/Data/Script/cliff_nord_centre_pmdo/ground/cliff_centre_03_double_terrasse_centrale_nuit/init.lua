-- cliff_centre_03_double_terrasse_centrale_nuit : animations ciel/mer 100 % natives PMDO 0.8.12
local cliff_centre_03_double_terrasse_centrale_nuit = {}
function cliff_centre_03_double_terrasse_centrale_nuit.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_03_double_terrasse_centrale_nuit

-- cliff_centre_07_cap_asymetrique_ouest_jour : falaise au premier plan 100 % canonique Métano + animations PMDO 0.8.12
local cliff_centre_07_cap_asymetrique_ouest_jour = {}
function cliff_centre_07_cap_asymetrique_ouest_jour.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_07_cap_asymetrique_ouest_jour

-- cliff_nord_centre_nue_jour : animations ciel/mer/cascade 100 % natives moteur PMDO 0.8.12
local cliff_nord_centre_nue_jour = {}
function cliff_nord_centre_nue_jour.Init(map)
  COMMON.RespawnAllies()
end
return cliff_nord_centre_nue_jour

-- cliff_centre_02_eperon_nord_effile_nuit : 100 % modules canoniques Métano + animations natives PMDO 0.8.12
local cliff_centre_02_eperon_nord_effile_nuit = {}
function cliff_centre_02_eperon_nord_effile_nuit.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_02_eperon_nord_effile_nuit

-- cliff_centre_02_eperon_nord_effile_nuit : animations ciel/mer 100 % natives PMDO 0.8.12
local cliff_centre_02_eperon_nord_effile_nuit = {}
function cliff_centre_02_eperon_nord_effile_nuit.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_02_eperon_nord_effile_nuit

-- cliff_centre_06_presquile_isthme_etroit_jour : animations ciel/mer 100 % natives PMDO 0.8.12
local cliff_centre_06_presquile_isthme_etroit_jour = {}
function cliff_centre_06_presquile_isthme_etroit_jour.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_06_presquile_isthme_etroit_jour

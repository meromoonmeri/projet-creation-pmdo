-- cliff_centre_08_cap_asymetrique_est_nuit : animations ciel/mer 100 % natives PMDO 0.8.12
local cliff_centre_08_cap_asymetrique_est_nuit = {}
function cliff_centre_08_cap_asymetrique_est_nuit.Init(map)
  COMMON.RespawnAllies()
end
return cliff_centre_08_cap_asymetrique_est_nuit

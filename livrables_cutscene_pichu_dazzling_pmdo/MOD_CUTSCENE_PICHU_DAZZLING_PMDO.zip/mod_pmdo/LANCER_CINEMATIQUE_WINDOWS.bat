@echo off
setlocal
set "MODDIR=%~dp0"
for %%I in ("%MODDIR%..\..") do set "GAMEDIR=%%~fI"
cd /d "%GAMEDIR%"
if not exist "%GAMEDIR%\PMDO.exe" (echo PMDO.exe introuvable. Placez ce mod dans PMDO\MODS\PichuDazzling.& pause & exit /b 1)
"%GAMEDIR%\PMDO.exe" -dev -quest "%MODDIR%"

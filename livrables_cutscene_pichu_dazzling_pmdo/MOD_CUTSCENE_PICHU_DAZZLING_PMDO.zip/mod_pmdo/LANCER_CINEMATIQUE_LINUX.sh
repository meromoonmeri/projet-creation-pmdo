#!/usr/bin/env bash
set -e
MODDIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
GAMEDIR="$(cd -- "$MODDIR/../.." && pwd)"
if [[ ! -x "$GAMEDIR/PMDO" ]]; then echo "PMDO introuvable. Placez ce mod dans PMDO/MODS/PichuDazzling." >&2; exit 1; fi
cd "$GAMEDIR"
exec "$GAMEDIR/PMDO" -dev -quest "$MODDIR"

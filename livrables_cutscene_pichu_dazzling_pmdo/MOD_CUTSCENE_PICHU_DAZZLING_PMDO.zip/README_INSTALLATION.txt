LIRE POUR VOIR LA CINEMATIQUE DANS LE VRAI MOTEUR PMDO 0.8.12

1) Fermer PMDO et extraire cette archive.
2) Copier le dossier mod_pmdo dans <PMDO>/MODS/PichuDazzling (Mod.xml doit rester à la racine de ce dossier). C'est une Quest indépendante : ne pas fusionner son index.idx avec un autre mod.
3) Depuis le dossier installé, lancer LANCER_CINEMATIQUE_WINDOWS.bat (Windows) ou LANCER_CINEMATIQUE_LINUX.sh (Linux). Le script démarre PMDO en mode développement avec cette Quest.
4) Dans le jeu, ouvrir le Dev Warp/l'éditeur Ground, choisir cliffdaytest et entrer au marqueur Pichu_Home_Door. À la première entrée, la cinématique démarre automatiquement. La variante nuit est cliffdaytest_nuit. Pour rejouer, effacer SV.PichuDazzling.Seen ou choisir une sauvegarde neuve.

Le mod inclut ses atlas .tile, index.idx et fonds .dir; il utilise les sprites Pokémon du PMDO installé. Les tests de structure, sprites, atlas et ZIP passent. Le moteur graphique PMDO n'a pas pu être lancé ici : le premier rendu en jeu reste à confirmer sur votre installation.

-- fgv1_fin_grotte_vasques : base d edition, aucun warp.
local fgv1_fin_grotte_vasques = {}
return fgv1_fin_grotte_vasques

-- ftx1_fin_traversee_cristalline : fin de donjon, aucune sortie, aucun warp.
local ftx1_fin_traversee_cristalline = {}
return ftx1_fin_traversee_cristalline

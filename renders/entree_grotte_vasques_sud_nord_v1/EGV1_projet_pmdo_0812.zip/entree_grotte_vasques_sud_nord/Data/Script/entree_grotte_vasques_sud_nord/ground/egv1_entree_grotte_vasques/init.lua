-- egv1_entree_grotte_vasques : marqueur de seuil seulement, aucun warp ni destination.
local egv1_entree_grotte_vasques = {}
return egv1_entree_grotte_vasques

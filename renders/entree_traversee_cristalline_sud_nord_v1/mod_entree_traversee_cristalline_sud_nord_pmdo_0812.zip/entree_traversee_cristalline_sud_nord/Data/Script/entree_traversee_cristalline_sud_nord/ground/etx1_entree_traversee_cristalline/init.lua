-- etx1_entree_traversee_cristalline : base d edition, aucun warp.
local etx1_entree_traversee_cristalline = {}
return etx1_entree_traversee_cristalline

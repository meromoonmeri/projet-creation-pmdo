-- ece1_entree_crevasse_enneigee : marqueur de seuil seulement, aucun warp ni destination.
local ece1_entree_crevasse_enneigee = {}
return ece1_entree_crevasse_enneigee
